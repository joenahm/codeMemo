import java.util.*;

public class 脑内海战{
	public static void main(String[] args) {
		Game nnhz = new Game();
		nnhz.start();

		Scanner scan = new Scanner(System.in);

		do{
			System.out.print("输入打击位置：");
		}while( !nnhz.guess(scan.nextInt()) );
	}
}

