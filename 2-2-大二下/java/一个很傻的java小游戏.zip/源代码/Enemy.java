class Enemy{
	private int[] location;

	Enemy(int[] loca){
		location = loca;
	}

	public boolean check(int userGuess){
		boolean status = false;

		for( int i = 0 ; i < location.length ; i++ ){
			if( location[i]!=-1 
			&& location[i]==userGuess ){
			
				status = true;
				location[i] = -1;
			}
		}

		return status;
	}

	public boolean isDead(){
		boolean status = true;
		
		for( int cell : location ){
			if( cell != -1 ){
				status = false;
			}
		}

		return status;
	}
}