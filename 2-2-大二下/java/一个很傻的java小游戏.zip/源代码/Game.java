class Game{
	private int numOfGuess;
	private Enemy dc;

	Game(){
		numOfGuess = 0;
	}

	public void start(){
		int[] location = new int[3];

		int initLoca = (int)(Math.random()*5);

		for( int i = 0 ; i < location.length ; i ++ ){
			location[i] = initLoca+i;
		}

		dc = new Enemy(location);

		System.out.println("脑内海战游戏开始！");
		System.out.println("从0～6中猜一个数，来攻击位于位置在0~6上的长度为3的敌船。\n");
	}

	public boolean guess(int value){
		if( dc.check(value) ){
			System.out.println("击中敌船！");
		}else{
			System.out.println("没有击中。");
		}

		numOfGuess++;

		if( dc.isDead() ){
			System.out.println("\n成功击败敌船！");
			System.out.println("一共猜了"+numOfGuess+"次！");

			return true;
		}else{
			return false;
		}
	}
}